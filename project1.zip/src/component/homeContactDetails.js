import React from 'react'

const homeContactDetails = () => {
  return (
    <div>homeContactDetails</div>
  )
}

export default homeContactDetails