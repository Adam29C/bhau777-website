import React from 'react'

const page = () => {
  return (
    <div>HowToPlay</div>
  )
}

export default page