"use client";
import React, { useEffect, useState } from "react";
// import { GET_CONTACT } from "../../service/admin.service";
// import { downloadAPK } from "../../Helpers/DownloadAPK";
import "../globals.css";
import Link from "next/link";
import HeaderSvg from "../../Helpers/HeaderSvg";
import Image from "next/image";
const Section2 = () => {
 

  return (
    <>
Home
    </>
  );
};

export default Section2;
